package com.example.cooking_pal_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
